/* Very elaborated function.  */

extern int successful_rtld_next_test (void);


int
successful_rtld_next_test (void)
{
  return 42;
}
