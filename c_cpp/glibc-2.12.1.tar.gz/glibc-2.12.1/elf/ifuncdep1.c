/* Test STT_GNU_IFUNC symbols without -fPIC.  */

#include "ifuncmod1.c"
