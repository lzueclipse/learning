/root/bin/apache-tomcat-8.0.32/bin/shutdown.sh
